import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class nicolas_project extends PApplet {

  //Specify number of cells in grid -- MODIFIABLE (MOD)
  int gridW = 256;
  int gridH = 160;
  //Determine size of each cell from size of grid and size of window
  int cellW=2048/gridW;
  int cellH=1280/gridH;
  
  int pauser = 0;
  
  //colour limits
  int bracket = 0;
  int lowLimR = 0-bracket;
  int uppLimR = 255+bracket;
  int lowLimG = 0-bracket;
  int uppLimG = 255+bracket;
  int lowLimB = 0-bracket;
  int uppLimB = 255+bracket;
  //paint gun
  int gunR = 255;
  int gunG = 100;
  int gunB = 50;
  int pelletSize = 1;

  Grid grid = new Grid();

  //Setup the sketch
  public void setup() {
    size(1024,640);
    background(255);
    grid.addCells();
    grid.findNeighbours();
  }

  public void draw() {
    grid.refresh();
    
    
    //pause button
    fill(255);
    rect(width-30,7,20,20);
    fill(0);
    rect(width-26,11,5,12);
    rect(width-19,11,5,12);
    
    //restart button
    fill(255);
    rect(width-30,32,20,20);
    stroke(0);
    ellipse(width-20,42,16,16);
    
    //export button
    fill(255);
    noStroke();
    rect(width-30,57,20,20);
    
//    filter(GRAY);

  }
  
  public void mousePressed() {
    if (mouseX > 994 && mouseX < 1014 && mouseY > 7 && mouseY < 27) {
      if (mousePressed) {
        pauser += 1;
      }
    }
    if (pauser%2 == 0) {
      loop();
    } else {
      noLoop();
    }
    if (mouseX > 994 && mouseX < 1014 && mouseY > 32 && mouseY < 52) {
      grid.cells.clear();
      grid.addCells();
      grid.findNeighbours();
    }
    
    if (mouseX > 994 && mouseX < 1014 && mouseY > 57 && mouseY < 77) {
      save("snap.jpg");
    }
    
  }
  

  class Grid {
    ArrayList<Cell> cells;

    Grid() {
      cells = new ArrayList<Cell>();
    }

    public void addCells() {
      //Use loop to reach every cell emplacement and add a cell in it
      int i,j;
      for (i=0; i<gridW; i++) {
        for (j=0; j<gridH; j++) {
          cells.add(new Cell(i*cellW,j*cellH, cellW, cellH));
        }
      }
    }
    
    public void findNeighbours() {
      //Loop to find neighbours, using logical statements for corners and edges
      for (Cell c : cells) {
       int index=cells.indexOf(c);
       if (c.cellX == 0) {
         if (c.cellY == 0) {
           c.neighbours.add(cells.get(index+gridH));
           c.neighbours.add(cells.get(index+1));
           c.neighbours.add(cells.get(index+gridH+1));
         }
         else if (c.cellY == (gridH-1)*cellH) {
           c.neighbours.add(cells.get(index+gridH));
           c.neighbours.add(cells.get(index-1));
           c.neighbours.add(cells.get(index+gridH-1));
         }
         else {
           c.neighbours.add(cells.get(index+gridH));
           c.neighbours.add(cells.get(index-1));
           c.neighbours.add(cells.get(index+gridH-1));
           c.neighbours.add(cells.get(index+1));
           c.neighbours.add(cells.get(index+gridH+1));
         }
       }
       else if (c.cellX == (gridW-1)*cellW) {
          if (c.cellY == 0) {
           c.neighbours.add(cells.get(index-gridH));
           c.neighbours.add(cells.get(index+1));
           c.neighbours.add(cells.get(index-gridH+1));
         }
         else if (c.cellY == (gridH-1)*cellH) {
           c.neighbours.add(cells.get(index-gridH));
           c.neighbours.add(cells.get(index-1));
           c.neighbours.add(cells.get(index-gridH-1));
         }
         else {
           c.neighbours.add(cells.get(index-gridH));
           c.neighbours.add(cells.get(index-1));
           c.neighbours.add(cells.get(index-gridH-1));
           c.neighbours.add(cells.get(index+1));
           c.neighbours.add(cells.get(index-gridH+1));
         }
       }
       else if (c.cellY == 0) {
          c.neighbours.add(cells.get(index-gridH));
          c.neighbours.add(cells.get(index+gridH));
          c.neighbours.add(cells.get(index-gridH+1));
          c.neighbours.add(cells.get(index+gridH+1));
          c.neighbours.add(cells.get(index+1));
       }
       else if (c.cellY == (gridH-1)*cellH) {
          c.neighbours.add(cells.get(index-gridH));
          c.neighbours.add(cells.get(index+gridH));
          c.neighbours.add(cells.get(index-gridH-1));
          c.neighbours.add(cells.get(index+gridH-1));
          c.neighbours.add(cells.get(index-1)); 
       }
       else {
          c.neighbours.add(cells.get(index-gridH));
          c.neighbours.add(cells.get(index+gridH));
          c.neighbours.add(cells.get(index+1)); 
          c.neighbours.add(cells.get(index-1));
          c.neighbours.add(cells.get(index-gridH-1));
          c.neighbours.add(cells.get(index+gridH-1));
          c.neighbours.add(cells.get(index-gridH+1));
          c.neighbours.add(cells.get(index+gridH+1));
       }
      }
    }
    
    public void refresh() {
      for (Cell c : cells) {
          c.update();  //updating each cell's colour
          c.paint();   //painting the cells if paintgun is used
          c.render();  // looping through all the cells to render each one
    }
    }
  }

  class Cell {

    int cellX, cellY, cellW, cellH;
    float cellR, cellG, cellB; //a cell's colours
    float tempR, tempG, tempB; //a temporary value for each colour to act as buffer during the update loop
    float cellVR, cellVG, cellVB; //velocity (rate at which it's evolving) for each colour
    float tempVR, tempVG, tempVB; //temporary velocity
    float cohR, cohG, cohB; //cohesion variable (average colour of neighbours)
    float aliR, aliG, aliB; //alignment variable (average velocity of neighbours)
    float sepR, sepG, sepB; //separation variable (to ensure cells don't all become the same colour)
    float rein = 0.5f; //a variable used to moderate the velocity
    int minDist = 1; //minimum distance for separation
    ArrayList<Cell> neighbours; //to hold the neighbours
    

    //Initialising cells with an x,y, width, height, initial random colour and null velocity (+empty neighbours array)
    Cell(int x, int y, int w, int h) {
      cellX = x;
      cellY = y;
      cellW = w;
      cellH = h;
      cellR = random(lowLimR,uppLimR);
      cellG = random(lowLimG,uppLimG);
      cellB = random(lowLimB,uppLimB);
      tempR = cellR; 
      tempG = cellG;
      tempB = cellB;
      cellVR = 0; 
      cellVG = 0;
      cellVB = 0;
      tempVR=0; 
      tempVG=0;
      tempVB=0;
      neighbours = new ArrayList<Cell>();
    }
    
    //function to update colour
    public void update() {
      cohR = cohG = cohB = 0;
      aliR = aliG = aliB = 0;
      sepR = sepG = sepB = 0;
      int num = 0; //counting neighbours
      //looping through neighbours to compute coh, ali, and sep values
      for (Cell n : neighbours) {
        cohR += n.cellR;
        cohG += n.cellG;
        cohB += n.cellB;
        aliR += n.cellVR;
        aliG += n.cellVG;
        aliB += n.cellVB;
        float distR = (cellR - n.cellR);
        float distG = (cellG - n.cellG);
        float distB = (cellB - n.cellB);
        if (distR*distR + distG*distG + distB*distB < minDist) {
          sepR += distR;
          sepG += distG;
          sepB += distB;
        }
        num++;
      }
      cohR = cohR/num;
      cohG = cohG/num;
      cohB = cohB/num;
      aliR = aliR/num;
      aliG = aliG/num;
      aliB = aliB/num;
      
      
      //updating the temporary velocity using the computed flocking values - using the rein to limit velocity
      tempVR += rein*(sepR + cohR + aliR - cellR - tempVR);
      tempVG += rein*(sepG + cohG + aliG - cellG - tempVG);
      tempVB += rein*(sepB + cohB + aliB - cellB - tempVB);
      
      //updating temp colour with velocity
      tempR += tempVR;
      tempG += tempVG;
      tempB += tempVB;
      
      float cc = -1.0f;
      
      //when a colour reaches an extreme value (0 or 255), these statements
      //cap the velocity and multiply it by -1 to send the colour back the other way
      
      if (tempR < lowLimR) {
        tempR = lowLimR;
        tempVR *= cc;
      }
      else if (tempR > uppLimR) {
        tempR = uppLimR;
        tempVR *= cc;
      }
      if (tempG < lowLimG) {
        tempG = lowLimG;
        tempVG *= cc;
      }
      else if (tempG > uppLimG) {
        tempG = uppLimG;
        tempVG *= cc;
      }
      if (tempB < lowLimB) {
        tempB = lowLimB;
        tempVB *= cc;
      }
      else if (tempB > uppLimB) {
        tempB = uppLimB;
        tempVB *= cc;
      }
    }

    // the render function creating a square using xywh and updated colours
    public void render() {
      cellR = tempR;
      cellG = tempG;
      cellB = tempB;
      cellVR = tempVR/2; //divided by two to give colours a chance
      cellVG = tempVG/2;
      cellVB = tempVB/2;
      
      fill(cellR,cellG,cellB);     
      noStroke();
      rect(cellX, cellY, cellW, cellH);
    }
    
    public void paint() {
    //defining the paintgun tool
      //don't do anything if user clicks on buttons
      if ((mouseX > 994 && mouseX < 1014 && mouseY > 7 && mouseY < 27) || 
      (mouseX > 994 && mouseX < 1014 && mouseY > 32 && mouseY < 52) ||
      (mouseX > 994 && mouseX < 1014 && mouseY > 57 && mouseY < 77) ) {
        
      }
      else {
        if (mousePressed == true) {
          //when mouse is pressed select the 8 cells around the mouse position
          if (mouseY-2*pelletSize*cellH < cellY && cellY < mouseY+cellH+pelletSize && mouseX-2*pelletSize*cellW < cellX && cellX < mouseX+cellW*pelletSize) {
            //update the colour of the cells according to rule
              cellR = tempR = gunR;
              cellG = tempG = gunG;
              cellB = tempB = gunB;
              tempVR = cellVR = 0;
              tempVG = cellVG = 0;
              tempVB = cellVB = 0;
          }
        }
      }
    }
    
  }

  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "nicolas_project" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
